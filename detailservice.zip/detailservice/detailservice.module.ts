import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailservicePage } from './detailservice';

@NgModule({
  declarations: [
    DetailservicePage,
  ],
  imports: [
    IonicPageModule.forChild(DetailservicePage),
  ],
})
export class DetailservicePageModule {}
