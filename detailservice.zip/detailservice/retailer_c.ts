export class Retailer
{
    constructor(public retailer_id:number,public retailer_email:string,
        public retailer_password:string,public retailer_name:string,
        public reatailer_city_id:number,public retailer_mobile:number,
        public retailer_pincode:number)
    {

    }
}